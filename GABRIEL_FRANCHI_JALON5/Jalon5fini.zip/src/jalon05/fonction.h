#ifndef FONCTION_H_
#define FONCTION_H_

#define SIZE_MSG 200

char *str_sub (const char *s, unsigned int start, unsigned int end);
char **str_split (char *s, const char *ct);
void describe_string(char* buffer);
char* get_1_arg(char* buffer);
char* get_2_arg(char* buffer, int position);
char* get_3_arg(char* buffer);


void do_connect(int sock_client, char hostname[], int port, struct sockaddr_in* sock_host);

#endif /* FONCTION_H_ */
