#ifndef FILE_H_
#define FILE_H_
#include "user.h"
#include "salon.h"

#include "fonction.h"
#define SIZE_MSG 200

int extract_file(char* buffer, char* receiving_user, char* filename, int position);
//Get the adress  from /connect <addr_p2p>
void extract_addr_p2p(struct user* tab_user, char* receiving_user,char* dest_addr,char* dest_port);



#endif /* FILE_H_ */
