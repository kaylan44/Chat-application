#ifndef USER_H_
#define USER_H_


//struct user;

struct user {
  char* nickname;
  char* date_conexion;
  char* addr_ip;
  int port;
  int id;
  char* salon;
};

struct user* init_tab_user(int max);
void set_user(struct user* user,  char* nickname, char* date_conexion, char* addr_ip, int port,int id);
void desc_user(struct user* user);
char* get_nickname(struct user* user);
int get_id(struct user* user);
char* get_user_salon(struct user* user);
void get_port(struct user* user,char* port);
char* get_address(struct user* user);
char* who(struct user* user);
void delete_user(struct user* user);
int user_existing(struct user* user);
int user_in_salon(struct user* user);

void getdate(char* date_in);
void whois_user(struct user* user, char* nickname, char* string_whois);
char* get_pseudo(char* buffer, int position);
void get_msgall(const char* buffer,char* msg);
void send_all(struct user* tab_user, char* msgall, int sending_user);

int extract_unicast(char* buffer, char* pseudo, char* msg_to_send, int postion);
void unicast(struct user* tab_user, char* buffer, int sending_user);

char* get_salon(struct user*);
void set_salon_user(struct user* user, char* name_salon);

void get_info_p2p(struct user* tab_user, char* name, char* dest_address);
struct sockaddr_in init_serv_addr(int port);
void change_nickname(struct user* user,  char* nickname);

#endif /* USER_H_ */
